﻿using EmailContentExtractor.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Text.RegularExpressions;

namespace EmailContentExtractor.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EmailExtractorController : ControllerBase
    {
        private readonly ILogger<EmailExtractorController> _logger;
        private readonly IOptions<TagConfig> _config;
        public EmailExtractorController(ILogger<EmailExtractorController> logger, IOptions<TagConfig> config)
        {
            _logger = logger;
            _config = config;
        }

        [HttpPost]
        public Result Post(String Body)
        {
            try
            {
                var _Result = new Result();
                Regex regex = new Regex(((Microsoft.Extensions.Options.OptionsManager<TagConfig>)_config).Value.Tag1);
                var v = regex.Match(Body);
                _Result.total = Convert.ToInt32(v.Groups[1].Value.Replace(",", ""));
                /* deducting sales tax of 10% from total*/
                _Result.salestax = _Result.total * ((Microsoft.Extensions.Options.OptionsManager<TagConfig>)_config).Value.ServiceTax;
                _Result.totalexcludingtax = _Result.total - _Result.salestax;
                regex = new Regex(((Microsoft.Extensions.Options.OptionsManager<TagConfig>)_config).Value.Tag2);
                v = regex.Match(Body);
                if(v != null && v.Length > 0)
                _Result.cost_centre = v.Groups[1].Value;

                return _Result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return null;
            }

        }

        [HttpGet]
        public String Get()
        {
            return "Welcome to Email Extractor";
        }

    }
    
}
