﻿namespace EmailContentExtractor.Models
{
    public class TagConfig
    {
        public string Tag1 { get; set; }
        public string Tag2 { get; set; }
        public double ServiceTax { get; set; }
    }
}
