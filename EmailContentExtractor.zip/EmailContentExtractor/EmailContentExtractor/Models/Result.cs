﻿using System;

namespace EmailContentExtractor.Models
{
    [Serializable]
    public class Result
    {
        public double total { get; set; }
        public double totalexcludingtax { get; set; }
        public double salestax { get; set; }
        public string cost_centre { get; set; } = "UNKNOWN";
    }
}
